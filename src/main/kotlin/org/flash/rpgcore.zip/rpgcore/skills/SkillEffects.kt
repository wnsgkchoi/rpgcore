// File: SkillEffects.kt
package org.flash.rpgcore.skills

import org.bukkit.Particle
import org.bukkit.Sound
import org.bukkit.entity.EntityType
import org.bukkit.entity.LivingEntity
import org.bukkit.entity.Monster
import org.bukkit.entity.Player
import org.bukkit.scheduler.BukkitRunnable
import org.bukkit.util.Vector
import org.flash.rpgcore.RPGCore
import org.flash.rpgcore.buff.BuffManager
import org.flash.rpgcore.combat.DamageCalculator
import org.flash.rpgcore.sidebar.SidebarService
import org.flash.rpgcore.stats.StatManager
import org.flash.rpgcore.util.VirtualHp
import kotlin.math.min

object SkillEffects {
    /* 안전 정규화: 길이 0이면 null */
    private fun Vector.safeNormalize(): Vector? =
        if (lengthSquared() == 0.0) null else clone().normalize()

    /* 넉백 최대 값 */
    private const val KB_MAX = 1.1

    /** 1. 광전사 전용 스킬 **/

    /**
     * 분노의 광휘: 제자리에서 회전하면서 반경 5칸 내 모든 몬스터에게 피해 + 넉백
     */
    fun rageWhirlwind(p: Player, physCoef: Double, magCoef: Double) {
        val center = p.location
        val weapon = p.inventory.itemInMainHand.type
        val atkStats = StatManager.load(p.uniqueId).finalAttack
        val magStats = StatManager.load(p.uniqueId).finalMagic

        p.world.getNearbyEntities(center, 5.0, 3.0, 5.0)
            .filterIsInstance<LivingEntity>()
            .filter { it != p && it is Monster }
            .forEach { target ->
                // 1) 피해
                val dmg = DamageCalculator.calc(p, weapon, target, physCoef, magCoef)
                target.damage(dmg, p)

                // 2) 넉백
                val dir = target.location.toVector()
                    .subtract(center.toVector())
                    .safeNormalize() ?: return@forEach
                val kb  = dir.multiply(min(KB_MAX, 1.0)).setY(0.35)
                if (kb.isFinite()) target.velocity = kb
            }

        // 이펙트
        p.world.playSound(center, Sound.ENTITY_PLAYER_ATTACK_SWEEP, 1f, 1f)
        p.world.spawnParticle(Particle.SWEEP_ATTACK, center, 20, 1.0, 0.5, 1.0, 0.1)
    }

    /**
     * 분쇄 강타: 큰 점프 후 착지 시 반경 6칸 내 몬스터에게 피해 + 넉백
     */
    fun crushBlow(p: Player, physCoef: Double, magCoef: Double) {
        // 1) 점프
        p.velocity = p.location.direction.setY(1.0).multiply(1.0)

        // 2) 착지 감지
        object : BukkitRunnable() {
            override fun run() {
                if (!p.isOnGround) return
                cancel()

                val center = p.location
                val world  = center.world
                val weapon = p.inventory.itemInMainHand.type

                // 착지 이펙트
                world.spawnParticle(Particle.EXPLOSION, center, 1, 0.0, 0.0, 0.0, 0.0)

                // 범위 피해 + 넉백
                val radius = 6.0
                world.getNearbyEntities(center, radius, radius, radius)
                    .filterIsInstance<LivingEntity>()
                    .filter { it != p && it !is Player && it is Monster }
                    .forEach { target ->
                        val dmg = DamageCalculator.calc(p, weapon, target, physCoef, magCoef)
                        target.damage(dmg, p)

                        val kb = target.location.toVector()
                            .subtract(center.toVector())
                            .normalize()
                            .multiply(1.0)
                            .setY(0.5)
                        if (kb.isFinite()) target.velocity = kb
                    }
            }
        }.runTaskTimer(RPGCore.INSTANCE, 0L, 2L)
    }

    /**
     * 결사의 일격: 체력 10%만 남기고 남은 HP를 절약해둔 뒤
     * 5초 내 좌클릭 시 첫 몬스터를 강력 일격
     */
    fun lastStand(p: Player, physCoef: Double, magCoef: Double) {
        val stats   = StatManager.load(p.uniqueId)
        val keepHp  = (stats.finalHP * 0.10).coerceAtLeast(1.0)
        val realHp  = p.health
        val virtHp  = VirtualHp.get(p).toDouble()
        val totalHp = realHp + virtHp

        if (totalHp <= keepHp) {
            p.sendActionBar("§cHP가 부족합니다!")
            return
        }

        var toLose   = totalHp - keepHp
        val virtTaken = virtHp.coerceAtMost(toLose)
        val newVirt   = virtHp - virtTaken
        toLose       -= virtTaken
        val newReal   = (realHp - toLose).coerceAtLeast(3.0)

        p.health = newReal
        VirtualHp.set(p, newVirt.toInt())
        SidebarService.updateNow(p)

        val hpLost = totalHp - keepHp
        p.sendActionBar("§4결사의 일격 준비!")

        object : BukkitRunnable() {
            var ticks = 100
            override fun run() {
                if (ticks-- <= 0 || !p.isOnline) { cancel(); return }

                val eye   = p.eyeLocation
                val dir   = eye.direction.normalize()
                val target = eye.world.getNearbyEntities(eye, 3.0, 3.0, 3.0)
                    .filterIsInstance<LivingEntity>()
                    .filter { it != p && it.type != EntityType.PLAYER && it is Monster }
                    .firstOrNull {
                        it.location.toVector().subtract(eye.toVector())
                            .normalize().dot(dir) > 0.8
                    }

                if (target != null && p.attackCooldown > 0.9f) {
                    val weapon = p.inventory.itemInMainHand.type
                    val base   = DamageCalculator.calc(p, weapon, target, physCoef, magCoef)
                    val extra  = hpLost * 0.30
                    val final  = base + extra

                    target.damage(final, p)
                    target.world.spawnParticle(
                        Particle.CRIT, target.location, 30, 0.4, 0.8, 0.4, 0.2
                    )
                    val kb = dir.multiply(1.2).setY(0.4)
                    if (kb.isFinite()) target.velocity = kb
                    cancel()
                }
            }
        }.runTaskTimer(RPGCore.INSTANCE, 0L, 1L)
    }

    /** 2. 탱커 전용 스킬 **/

    /**
     * 방패 돌진: 최대 5칸 대시, 충돌 시 적 1인에게 데미지+넉백,
     * 주변 AoE 피해 후 1초 무적 적용
     */
    fun shieldCharge(p: Player, physCoef: Double, magCoef: Double) {
        val weapon = p.inventory.itemInMainHand.type
        val world  = p.world
        val start  = p.location
        val dir    = start.direction.setY(0.0).normalize()
        val MAX_DIST     = 5.0
        val ENTITY_TRACE = 1.5

        val blockHit = world.rayTraceBlocks(start, dir, MAX_DIST)
        val blockDist = blockHit?.hitPosition
            ?.distance(start.toVector()) ?: MAX_DIST

        val entHit = world.rayTraceEntities(
            start, dir, MAX_DIST, ENTITY_TRACE
        ) { it is Monster && it != p }
        val entDist = entHit?.hitPosition
            ?.distance(start.toVector()) ?: Double.MAX_VALUE

        val dashDist = minOf(blockDist, entDist, MAX_DIST)
        val dest     = start.clone().add(dir.clone().multiply(dashDist))
        p.teleport(dest)
        p.noDamageTicks = p.maximumNoDamageTicks

        entHit?.hitEntity
            ?.takeIf { entDist < blockDist && it is Monster }
            ?.let { target ->
                target as Monster
                val dmg = DamageCalculator.calc(p, weapon, target, physCoef, magCoef)
                target.damage(dmg, p)
                val kb = dir.multiply(1.0)
                if (kb.isFinite()) target.velocity = kb
            }

        val center = entHit?.hitPosition?.toLocation(world) ?: dest
        world.getNearbyEntities(center, 5.0, 5.0, 5.0)
            .filterIsInstance<LivingEntity>()
            .filter { it != p && it != entHit?.hitEntity && it is Monster }
            .forEach { victim ->
                val dmg = DamageCalculator.calc(p, weapon, victim, physCoef, magCoef)
                victim.damage(dmg, p)
            }

        world.spawnParticle(Particle.CLOUD, dest, 25, .6, .6, .6, .15)
        world.playSound(dest, Sound.ITEM_SHIELD_BLOCK, 1f, 1f)
    }

    /**
     * 도발: 주변 10칸 몬스터의 타겟을 자신으로 지정 (4초 지속)
     */
    fun taunt(p: Player) {
        val range = 10.0
        val dur   = 80L
        val mobs = p.getNearbyEntities(range, range, range)
            .filterIsInstance<Monster>()
        if (mobs.isEmpty()) {
            p.sendActionBar("§7주변에 몬스터 없음")
            return
        }
        p.sendActionBar("§e몬스터를 도발했습니다!")
        object : BukkitRunnable() {
            var ticks = dur
            override fun run() {
                if (ticks-- <= 0 || !p.isOnline) { cancel(); return }
                mobs.forEach { it.target = p }
            }
        }.runTaskTimer(RPGCore.INSTANCE, 0L, 10L)
    }

    /**
     * 꿰뚫는 가시: 방어력 비례 반사 버프 (10초 기본)
     */
    fun piercingThorns(p: Player, physCoef: Double, magCoef: Double, duration: Int) {
        val uuid = p.uniqueId
        if (BuffManager.isActive(uuid, "piercing_thorns")) {
            p.sendActionBar("§e이미 활성화되어 있습니다!")
            return
        }
        BuffManager.activate(uuid, "piercing_thorns", physCoef, duration)
        p.sendActionBar("§a꿰뚫는 가시 발동! (${duration}s)")
        p.world.playSound(p.location, Sound.ITEM_SHIELD_BLOCK, 1f, 1.2f)
    }

    /* Vector 가 유한한 값인지 검사 */
    private fun Vector.isFinite(): Boolean =
        !(x.isNaN() || y.isNaN() || z.isNaN()
                || x.isInfinite() || y.isInfinite() || z.isInfinite())
}
