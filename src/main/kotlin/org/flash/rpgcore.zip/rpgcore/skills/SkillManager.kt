// File: SkillManager.kt
package org.flash.rpgcore.skills

import java.util.*

data class PlayerSkills(
    val learned: MutableMap<String, Int> = mutableMapOf(),
    var slot1: Pair<String, Int>? = null,
    var slot2: Pair<String, Int>? = null,
    var slot3: Pair<String, Int>? = null
) {
    fun get(slot: Int) = when (slot) {
        1 -> slot1; 2 -> slot2; 3 -> slot3; else -> null
    }
    fun set(slot: Int, value: Pair<String, Int>?) {
        when (slot) {
            1 -> slot1 = value
            2 -> slot2 = value
            3 -> slot3 = value
        }
    }
}

object SkillManager {
    private val cache = mutableMapOf<UUID, PlayerSkills>()

    fun getSkills(uuid: UUID): PlayerSkills =
        cache.computeIfAbsent(uuid) {
            val ps = PlayerSkills()
            // 1) 학습된 레벨 로드
            ps.learned.putAll( SkillStore.loadLearnedLevels(uuid) )
            // 2) 슬롯(1~3) 로드
            for (s in 1..3) {
                SkillStore.loadSkillId(uuid, s)?.let { id ->
                    val lvl = SkillStore.loadSkillLevel(uuid, s)
                    ps.set(s, id to lvl)
                    // 슬롯 레벨이 learned보다 크면 learned에 반영
                    val prev = ps.learned[id] ?: 0
                    if (lvl > prev) ps.learned[id] = lvl
                }
            }
            // 3) 혹시 새로 추가된 learned가 있으면 저장
            SkillStore.saveLearnedLevels(uuid, ps.learned)
            ps
        }

    fun learnSkill(uuid: UUID, skillId: String, level: Int = 1) {
        val ps   = getSkills(uuid)
        val prev = ps.learned[skillId] ?: 0
        if (level > prev) {
            ps.learned[skillId] = level
            SkillStore.saveLearnedLevels(uuid, ps.learned)
        }
    }

    fun updateSkill(uuid: UUID, slot: Int, skillId: String?, level: Int) {
        val ps = getSkills(uuid)
        ps.set(slot, skillId?.let { it to level })
        SkillStore.saveSkill(uuid, slot, skillId, level)
        // learned 동기화
        if (skillId != null) {
            val prev = ps.learned[skillId] ?: 0
            if (level > prev) {
                ps.learned[skillId] = level
                SkillStore.saveLearnedLevels(uuid, ps.learned)
            }
        }
    }

    fun clear(uuid: UUID) = cache.remove(uuid)

    fun reloadAllPlayers() {
        cache.clear()
        // GUI re-open logic if needed
    }
}
