// File: SkillUseListener.kt  (쿨다운 검사/설정 추가)
package org.flash.rpgcore.skills

import org.bukkit.entity.Player
import org.bukkit.event.EventHandler
import org.bukkit.event.Listener
import org.bukkit.event.block.Action
import org.bukkit.event.player.PlayerInteractEvent
import org.bukkit.event.player.PlayerSwapHandItemsEvent
import org.flash.rpgcore.classs.ClassManager
import org.flash.rpgcore.sidebar.SidebarService
import org.flash.rpgcore.util.VirtualMp
import org.flash.rpgcore.util.WeaponRules
import org.flash.rpgcore.skills.SkillEffects

class SkillUseListener : Listener {

    // 1번 슬롯: 우클릭 → 스킬1
    @EventHandler
    fun onRightClick(e: PlayerInteractEvent) {
        val p   = e.player
        val cls = ClassManager.get(p.uniqueId)
        if (!WeaponRules.allowed(cls, p.inventory.itemInMainHand.type)) return
        if (e.action !in listOf(Action.RIGHT_CLICK_AIR, Action.RIGHT_CLICK_BLOCK)) return

        e.isCancelled = true
        useSkillSlot(p, slot = 1)
    }

    // 2→Sneak?3번 슬롯: 스왑핸드 키
    @EventHandler
    fun onSwapHand(e: PlayerSwapHandItemsEvent) {
        val p   = e.player
        val cls = ClassManager.get(p.uniqueId)
        if (!WeaponRules.allowed(cls, p.inventory.itemInMainHand.type)) return

        e.isCancelled = true
        if (p.isSneaking) useSkillSlot(p, slot = 3)
        else             useSkillSlot(p, slot = 2)
    }

    private fun useSkillSlot(p: Player, slot: Int) {
        val entry = SkillManager.getSkills(p.uniqueId).get(slot)
        if (entry == null) {
            p.sendActionBar("§c장착된 스킬이 없습니다.")
            return
        }
        val (skillId, level) = entry
        val def = SkillDefs.get(skillId) ?: run {
            p.sendActionBar("§c알 수 없는 스킬입니다.")
            return
        }

        // 0) 쿨타임 체크
        if (CooldownManager.isCooling(p.uniqueId, skillId)) {
            val sec = CooldownManager.getRemainingSeconds(p.uniqueId, skillId)
            p.sendActionBar("§e쿨타임 중: ${sec}초 남음")
            return
        }

        executeSkill(p, def, level)
    }

    private fun executeSkill(p: Player, def: SkillDefinition, level: Int) {
        if (level !in 1..def.maxLevel) {
            return p.sendActionBar("§c유효하지 않은 스킬 레벨입니다.")
        }
        val cost = def.getMpCost(level)
        if (VirtualMp.get(p) < cost) {
            return p.sendActionBar("§cMP가 부족합니다: 필요 $cost, 현재 ${VirtualMp.get(p)}")
        }

        // MP 차감 & 사이드바 갱신
        VirtualMp.subtract(p, cost)
        SidebarService.updateNow(p)

        // 계수 꺼내기
        val physCoef = def.getAtkCoef(level)
        val magCoef  = def.getMagCoef(level)

        // 쿨다운 설정
        val cd = def.getCooldown(level)
        CooldownManager.setCooldown(p.uniqueId, def.id, cd)

        // 스킬별 효과 호출
        when (def.id) {
            "rage_whirlwind" -> SkillEffects.rageWhirlwind(p, physCoef, magCoef)
            "crush_blow"     -> SkillEffects.crushBlow(p, physCoef, magCoef)
            "last_stand"     -> SkillEffects.lastStand(p, physCoef, magCoef)
            "shield_charge"  -> SkillEffects.shieldCharge(p, physCoef, magCoef)
            "taunt"          -> SkillEffects.taunt(p)                          // 비데미지 계열
            "piercing_thorns"-> SkillEffects.piercingThorns(p, physCoef, magCoef, cd.toInt())
            else             -> p.sendActionBar("§c지원되지 않는 스킬입니다.")
        }
    }
}
