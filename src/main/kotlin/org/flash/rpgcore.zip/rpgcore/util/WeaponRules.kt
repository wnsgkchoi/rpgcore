package org.flash.rpgcore.util

import org.bukkit.Material
import org.flash.rpgcore.classs.PlayerClass

object WeaponRules {
    /**
     * 클래스-전용 무기 허용 여부
     */
    fun allowed(cls: PlayerClass, weapon: Material): Boolean = when (cls) {
        PlayerClass.BERSERKER -> weapon.name.endsWith("_AXE")
        PlayerClass.TANK      -> weapon.name.endsWith("_SWORD")
        PlayerClass.HITMAN    -> weapon == Material.CROSSBOW
        PlayerClass.SNIPER    -> weapon == Material.BOW
        PlayerClass.ELEMENTIST      -> weapon.name.endsWith("_SHOVEL")
        PlayerClass.NOVICE    -> true
    }
}
