package org.flash.rpgcore.combat

import kotlin.math.max
import org.bukkit.Material
import org.bukkit.entity.LivingEntity
import org.bukkit.entity.Player
import org.flash.rpgcore.stats.StatManager
import org.flash.rpgcore.classs.ClassManager
import org.flash.rpgcore.classs.PlayerClass
import org.flash.rpgcore.combat.CombatListener
import org.flash.rpgcore.util.VirtualHp
import org.flash.rpgcore.util.WeaponRules
import kotlin.math.sqrt

object DamageCalculator {
    /* 유효 무기 검증을 CombatListener.allowed() 재사용 */
    fun calc(
        attacker: Player,
        weapon: Material,
        target: LivingEntity,
        physCoef: Double = 1.0,
        magicCoef: Double = 0.0
    ): Double {
        val atkStats = StatManager.load(attacker.uniqueId)
        val defStats =
            if (target is Player) StatManager.load(target.uniqueId) else null

        val valid = if (WeaponRules.allowed(
                ClassManager.get(attacker.uniqueId), weapon)) 1 else 0

        val cls = ClassManager.get(attacker.uniqueId)
        val hpNow = attacker.health.toInt() + VirtualHp.get(attacker)
        val hpMax = StatManager.load(attacker.uniqueId).finalHP
        val lost = (hpMax - hpNow).toDouble()
        val bonus = if (cls == PlayerClass.BERSERKER)
            (lost * sqrt(lost) * 0.05).toInt() else 0

        val atk = atkStats.finalAttack + bonus
        val def   = defStats?.finalDefense ?: 0.0
        val mag = atkStats.finalMagic
        val mdef = defStats?.finalMdef ?: 0.0

        val ad = valid * physCoef * atk * 50 / (50 + def)
        val ap = valid * magicCoef * mag * 50 / (50 + mdef)

        return max(1.0, ad + ap)
    }
}