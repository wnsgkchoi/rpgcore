package org.flash.rpgcore.combat

import org.bukkit.Bukkit
import org.bukkit.Material
import org.bukkit.entity.LivingEntity
import org.bukkit.entity.Player
import org.bukkit.entity.Projectile
import org.bukkit.event.EventHandler
import org.bukkit.event.EventPriority
import org.bukkit.event.Listener
import org.bukkit.event.entity.EntityDamageByEntityEvent
import org.bukkit.event.entity.EntityDamageEvent
import org.flash.rpgcore.RPGCore
import org.flash.rpgcore.buff.BuffManager
import org.flash.rpgcore.classs.ClassManager
import org.flash.rpgcore.classs.PlayerClass
import org.flash.rpgcore.sidebar.SidebarService
import org.flash.rpgcore.stats.StatManager
import org.flash.rpgcore.util.WeaponRules

class CombatListener : Listener {
    /** 근접 공격 계산 **/
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    fun onMelee(e: EntityDamageByEntityEvent) {
        val attacker = e.damager as? Player ?: return
        val victim   = e.entity  as? LivingEntity ?: return
        val clsA     = ClassManager.get(attacker.uniqueId)
        val weapon   = attacker.inventory.itemInMainHand.type

        if (!WeaponRules.allowed(clsA, weapon)) {
            e.damage = 0.0
            return
        }

        e.damage = DamageCalculator.calc(attacker, weapon, victim, 1.0, 0.0)
    }

    /**
     * 모든 EntityDamageEvent 에서 탱커/마법사 패시브와
     * 무적시간 설정(버퍼 피해 포함)을 처리합니다.
     */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    fun onPlayerDamaged(e: EntityDamageEvent) {
        val victim = (e.entity as? Player) ?: return
        val cls    = ClassManager.get(victim.uniqueId)

        if (victim.noDamageTicks > 0) {
            e.isCancelled = true
            return
        }

        // 1) 탱커 패시브: 모든 피해 50% 경감 + 반사
        if (cls == PlayerClass.TANK) {
            val orig  = e.damage
            val taken = orig * 0.5
            e.damage  = taken

            var reflect = taken * 0.05 +
                    StatManager.load(victim.uniqueId).finalAttack * 0.15

            if (BuffManager.isActive(victim.uniqueId, "piercing_thorns")) {
                val coef = BuffManager.coef(victim.uniqueId, "piercing_thorns")
                val def  = StatManager.load(victim.uniqueId).finalDefense
                reflect += def * coef
            }

            // 반사 대미지를 이벤트가 아닌 직접 체력에서 빼 버리기
            if (e is EntityDamageByEntityEvent) {
                val source = e.damager
                val damagerEntity = when (source) {
                    is LivingEntity -> source
                    is Projectile   -> (source.shooter as? LivingEntity)
                    else            -> null
                }
                damagerEntity?.let { d ->
                    val targetDef = (d as? Player)
                        ?.let { StatManager.load(it.uniqueId).finalDefense.toDouble() }
                        ?: 0.0
                    val raw     = reflect * 50.0 / (50.0 + targetDef)
                    val amount  = maxOf(1.0, raw)

                    // **여기**: damager.damage(amount) 대신 직접 체력에서 차감
                    d.health = (d.health - amount).coerceAtLeast(0.0)
                }
            }

            victim.world.playSound(
                victim.location,
                org.bukkit.Sound.ENTITY_PLAYER_HURT, 1f, 1f
            )
            victim.noDamageTicks = 20
            SidebarService.updateNow(victim)
            return
        }

        // 2) 마법사 패시브: MP 흡수
        if (cls == PlayerClass.ELEMENTIST) {
            val taken = e.damage
            val st    = StatManager.load(victim.uniqueId)
            val useMp = (taken * 0.6).toInt().coerceAtMost(st.mp)
            st.mp    -= useMp
            e.damage = taken * 0.4
            victim.noDamageTicks = 20
            SidebarService.updateNow(victim)
            return
        }

        // 그 외 플레이어는 기본 무적시간
        victim.noDamageTicks = victim.maximumNoDamageTicks
    }

    /** Non-player entity 에게만 무적시간 해제 **/
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    fun onAnyEntityDamageClearInvuln(e: EntityDamageEvent) {
        val victim = e.entity as? LivingEntity ?: return
        if (victim is Player) return
        Bukkit.getScheduler().runTaskLater(RPGCore.INSTANCE, Runnable {
            if (!victim.isDead) victim.noDamageTicks = 0
        }, 1L)
    }
}
