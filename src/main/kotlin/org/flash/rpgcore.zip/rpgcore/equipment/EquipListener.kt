package org.flash.rpgcore.equipment

import org.bukkit.event.Listener
import org.bukkit.event.EventHandler
import org.bukkit.event.inventory.InventoryClickEvent
import org.bukkit.entity.Player
import org.bukkit.inventory.ItemStack
import org.bukkit.Material
import org.bukkit.event.player.PlayerJoinEvent
import org.bukkit.event.player.PlayerQuitEvent
import org.bukkit.persistence.PersistentDataType
import org.flash.rpgcore.equipment.EquipGUI
import org.flash.rpgcore.equipment.EquipManager
import org.flash.rpgcore.equipment.ItemKeys
import org.flash.rpgcore.equipment.ItemFactory
import org.flash.rpgcore.equipment.EquipmentDefs
import org.flash.rpgcore.equipment.EquipSlot
import org.flash.rpgcore.stats.StatManager
import org.flash.rpgcore.sidebar.SidebarService
import java.util.Random
import java.util.UUID

class EquipListener : Listener {

    private val store = EquipStore

    @EventHandler(ignoreCancelled = true)
    fun onClick(e: InventoryClickEvent) {
        // 1) 장비창이 아니면 무시
        if (e.view.title() != EquipGUI.TITLE) return
        val player = e.whoClicked as? Player ?: return
        if (e.isShiftClick) { e.isCancelled = true; return }
        val uuid   = player.uniqueId

        // 2) rawSlot 으로 “상단 vs 하단” 분기
        val topSize = e.view.topInventory.size
        if (e.rawSlot >= topSize) {
            // 하단(플레이어 인벤토리)은 건드리지 않고 반환
            return
        }

        // 3) 이제부터 상단 클릭 → 기본 이동 동작 모두 차단
        e.isCancelled = true

        // 4) 인덱스 ↔ 파츠 매핑 준비
        val partMap = EquipGUI.SLOT_IDX.entries.associate { it.value to it.key }
        val enhMap  = EquipGUI.ENH_IDX.entries.associate  { it.value to it.key }

        // 5) Shift-클릭으로 언장착 지원
        if (e.isShiftClick) {
            partMap[e.slot]?.let { part ->
                // cursor 와 currentItem 은 건드릴 필요 없이,
                // handleEquipUnequip 내부에서 e.isShiftClick 감지로 언장착 구현하거나
                // 아예 아래처럼 직접 세팅해도 됩니다.
                handleEquipUnequip(uuid, part, player, e)
                EquipGUI.open(player)
            }
            return
        }

        // 6) 일반 클릭(좌/우) 처리
        when {
            // 제작 버튼
            e.slot == EquipGUI.CRAFT_IDX -> {
                // TODO: Recipe GUI 열기
            }
            // 강화 버튼
            enhMap.containsKey(e.slot) -> {
                val part = enhMap[e.slot]!!
                handleEnhance(uuid, part, player)
                EquipGUI.open(player)
            }
            // 장착 슬롯 클릭
            partMap.containsKey(e.slot) -> {
                val part = partMap[e.slot]!!
                handleEquipUnequip(uuid, part, player, e)
                EquipGUI.open(player)
            }
            // 그 외(장식용 빈슬롯 등)는 아무 동작도 하지 않음
        }
    }

    @EventHandler
    fun onQuit(e: PlayerQuitEvent) {
        val uuid  = e.player.uniqueId
        val slots = EquipManager.getSlots(uuid)

        // toMap() 덕분에 각 파츠와 해당 ItemStack? 을 순회하면서 저장 가능
        slots.toMap().forEach { (part, item) ->
            EquipStore.saveItem(uuid, part.name.lowercase(), item)
        }
    }

    /**
     * 강화 처리
     */
    private fun handleEnhance(uuid: UUID, part: EquipSlot, player: Player) {
        val slots    = EquipManager.getSlots(uuid)
        val equipped = when (part) {
            EquipSlot.WEAPON   -> slots.weapon
            EquipSlot.HELMET   -> slots.helmet
            EquipSlot.CHEST    -> slots.chest
            EquipSlot.LEGS     -> slots.legs
            EquipSlot.BOOTS    -> slots.boots
            EquipSlot.RING     -> slots.ring
            EquipSlot.NECKLACE -> slots.necklace
            EquipSlot.BRACELET -> slots.bracelet
            EquipSlot.CAPE     -> slots.cape
            EquipSlot.GLOVES   -> slots.gloves
            EquipSlot.EARRING  -> slots.earring
            EquipSlot.BELT     -> slots.belt
        }
        if (equipped == null || equipped.type.isAir) {
            player.sendActionBar("§c장착된 장비가 없습니다")
            return
        }

        val pdc  = equipped.itemMeta!!.persistentDataContainer
        val id   = pdc.get(ItemKeys.EQUIP_ID, PersistentDataType.STRING) ?: return
        val def  = EquipmentDefs.get(id) ?: return
        val lvl  = pdc.getOrDefault(ItemKeys.ENH_LEVEL, PersistentDataType.INTEGER, 0)
        if (lvl >= def.maxEnhance) {
            player.sendActionBar("§c최대 강화 단계입니다")
            return
        }

        // next-level cost & chance
        val xpCost  = def.xpCost[lvl + 1]
        val sucRate = def.successRate[lvl + 1]

        if (player.totalExperience < xpCost) {
            player.sendActionBar("§cXP가 부족합니다: 필요 $xpCost")
            return
        }
        player.giveExp(-xpCost)

        if (Random().nextDouble() < sucRate) {
            val nextItem = ItemFactory.create(def, lvl + 1)

            // ① 메모리 슬롯 업데이트
            when (part) {
                EquipSlot.WEAPON   -> slots.weapon   = nextItem
                EquipSlot.HELMET   -> slots.helmet   = nextItem
                EquipSlot.CHEST    -> slots.chest    = nextItem
                EquipSlot.LEGS     -> slots.legs     = nextItem
                EquipSlot.BOOTS    -> slots.boots    = nextItem
                EquipSlot.RING     -> slots.ring     = nextItem
                EquipSlot.NECKLACE -> slots.necklace = nextItem
                EquipSlot.BRACELET -> slots.bracelet = nextItem
                EquipSlot.CAPE     -> slots.cape     = nextItem
                EquipSlot.GLOVES   -> slots.gloves   = nextItem
                EquipSlot.EARRING  -> slots.earring  = nextItem
                EquipSlot.BELT     -> slots.belt     = nextItem
            }

            // ② 즉시 디스크에 저장 (여기서 빠졌던 부분)
            EquipStore.saveItem(uuid, part.name.lowercase(), nextItem)

            player.sendActionBar("§a강화 성공! 레벨 $lvl → ${lvl + 1}")
        } else {
            player.sendActionBar("§c강화 실패…")
        }

        // ③ 스탯 재계산 & 사이드바 갱신
        StatManager.recalcFor(player)
        SidebarService.updateNow(player)
    }

    /**
     * 장비 장착 / 해제 처리
     */
    private fun handleEquipUnequip(
        uuid: UUID,
        part: EquipSlot,
        player: Player,
        e: InventoryClickEvent
    ) {
        val slots  = EquipManager.getSlots(uuid)
        val cursor = e.cursor
        val current= e.currentItem

        // • 해제: 커서 비어 있고, 슬롯에 있던 장비가 클릭되었을 때
        if ((cursor == null || cursor.type.isAir) &&
            (current != null && !current.type.isAir)
        ) {
            when(part) {
                EquipSlot.WEAPON   -> slots.weapon   = null
                EquipSlot.HELMET   -> slots.helmet   = null
                EquipSlot.CHEST    -> slots.chest    = null
                EquipSlot.LEGS     -> slots.legs     = null
                EquipSlot.BOOTS    -> slots.boots    = null
                EquipSlot.RING     -> slots.ring     = null
                EquipSlot.NECKLACE -> slots.necklace = null
                EquipSlot.BRACELET -> slots.bracelet = null
                EquipSlot.CAPE     -> slots.cape     = null
                EquipSlot.GLOVES   -> slots.gloves   = null
                EquipSlot.EARRING  -> slots.earring  = null
                EquipSlot.BELT     -> slots.belt     = null
            }
            e.setCursor(current)
            e.setCurrentItem(ItemStack(Material.AIR))
            EquipStore.saveItem(uuid, part.name.lowercase(), null)
            StatManager.recalcFor(player)
            SidebarService.updateNow(player)
        }
        // • 장착: 커서에 아이템 있고, 슬롯이 빈 경우
        else if ((cursor != null && !cursor.type.isAir) &&
            (current == null || current.type.isAir)
        ) {
            if (!cursor.isValidEquipmentFor(part)) {
                player.sendActionBar("§c해당 부위 장비만 착용 가능합니다")
                return
            }
            when(part) {
                EquipSlot.WEAPON   -> slots.weapon   = cursor.clone()
                EquipSlot.HELMET   -> slots.helmet   = cursor.clone()
                EquipSlot.CHEST    -> slots.chest    = cursor.clone()
                EquipSlot.LEGS     -> slots.legs     = cursor.clone()
                EquipSlot.BOOTS    -> slots.boots    = cursor.clone()
                EquipSlot.RING     -> slots.ring     = cursor.clone()
                EquipSlot.NECKLACE -> slots.necklace = cursor.clone()
                EquipSlot.BRACELET -> slots.bracelet = cursor.clone()
                EquipSlot.CAPE     -> slots.cape     = cursor.clone()
                EquipSlot.GLOVES   -> slots.gloves   = cursor.clone()
                EquipSlot.EARRING  -> slots.earring  = cursor.clone()
                EquipSlot.BELT     -> slots.belt     = cursor.clone()
            }
            EquipStore.saveItem(uuid, part.name.lowercase(), slots.get(part))
            e.setCursor(ItemStack(Material.AIR))
            StatManager.recalcFor(player)
            SidebarService.updateNow(player)
        }
    }

    fun onPlayerJoin(e: PlayerJoinEvent) {
        StatManager.recalcFor(e.player)
    }

    /**
     * 이 ItemStack이 해당 부위에 착용 가능한 장비인지 검사
     */
    private fun ItemStack.isValidEquipmentFor(slot: EquipSlot): Boolean {
        if (type.isAir) return false
        val pdc = itemMeta?.persistentDataContainer ?: return false
        val id  = pdc.get(ItemKeys.EQUIP_ID, PersistentDataType.STRING) ?: return false
        val def = EquipmentDefs.get(id) ?: return false
        return def.slot == slot
    }
}
