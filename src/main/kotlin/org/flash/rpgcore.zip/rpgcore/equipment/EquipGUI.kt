package org.flash.rpgcore.equipment

import net.kyori.adventure.text.Component
import net.kyori.adventure.text.format.NamedTextColor
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
import org.bukkit.Bukkit
import org.bukkit.Material
import org.bukkit.NamespacedKey
import org.bukkit.entity.Player
import org.bukkit.inventory.Inventory
import org.bukkit.inventory.ItemFlag
import org.bukkit.inventory.ItemStack
import org.bukkit.persistence.PersistentDataType
import org.flash.rpgcore.RPGCore
import org.flash.rpgcore.equipment.EquipSlot
import org.flash.rpgcore.equipment.EquipSlot.*
import java.util.*

object EquipGUI {
    private const val SIZE = 54
    val TITLE: Component = Component.text("§6§l[장비 창]")
    private val LEGACY = LegacyComponentSerializer.legacySection()
    private val plugin = RPGCore.INSTANCE

    // 12 부위 → (row, col) 인벤 슬롯 매핑
    private val PART_SLOT = mapOf(
        EquipSlot.HELMET    to Pair(0,1),
        EquipSlot.RING      to Pair(0,4),
        EquipSlot.NECKLACE  to Pair(0,7),
        EquipSlot.CHEST     to Pair(1,1),
        EquipSlot.BRACELET  to Pair(1,4),
        EquipSlot.CAPE      to Pair(1,7),
        EquipSlot.LEGS      to Pair(2,1),
        EquipSlot.GLOVES    to Pair(2,4),
        EquipSlot.EARRING   to Pair(2,7),
        EquipSlot.BOOTS     to Pair(3,1),
        EquipSlot.BELT      to Pair(3,4),
        EquipSlot.WEAPON    to Pair(3,7)
    )

    private fun idx(r: Int, c: Int) = r*9 + c
    val SLOT_IDX = PART_SLOT.mapValues { (_, rc) -> idx(rc.first, rc.second) }
    val ENH_IDX  = PART_SLOT.mapValues { (_, rc) -> idx(rc.first, rc.second + 1) }
    val CRAFT_IDX = 49

    fun open(player: Player) {
        val inv: Inventory = Bukkit.createInventory(null, SIZE, TITLE)

        // 회색 유리 라벨
        fun label(text: String) = ItemStack(Material.GRAY_STAINED_GLASS_PANE).apply {
            itemMeta = itemMeta!!.apply {
                displayName( LEGACY.deserialize(text) )
                addItemFlags(ItemFlag.HIDE_ATTRIBUTES)
            }
        }

        // Anvil 아이콘 (강화 버튼)
        val anvil = ItemStack(Material.ANVIL).apply {
            itemMeta = itemMeta!!.apply {
                displayName(Component.text("§e우클릭: 강화", NamedTextColor.YELLOW))
                addItemFlags(ItemFlag.HIDE_ATTRIBUTES)
            }
        }

        // ① 라벨 배치
        SLOT_IDX.forEach { (partKey, slot) ->
            inv.setItem(slot - 1, label("§f[${partKey.name.lowercase().uppercase()}]"))
        }

        // ② 장착 아이템 + 강화 버튼
        SLOT_IDX.forEach { (part, slot) ->
            val item = EquipStore.loadItem(player.uniqueId, part.name.lowercase())
            inv.setItem(slot, item ?: ItemStack(Material.AIR))

            inv.setItem(ENH_IDX[part]!!, anvil)
        }

        // ③ 제작 버튼
        inv.setItem(CRAFT_IDX,
            ItemStack(Material.CRAFTING_TABLE).apply {
                itemMeta = itemMeta!!.apply {
                    displayName(Component.text("§a장비 제작", NamedTextColor.GREEN))
                    addItemFlags(ItemFlag.HIDE_ATTRIBUTES)
                }
            }
        )

        player.openInventory(inv)
    }
}
