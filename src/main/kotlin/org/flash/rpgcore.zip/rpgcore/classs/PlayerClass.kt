package org.flash.rpgcore.classs

enum class PlayerClass(val display: String) {
    NOVICE("초보자"),
    BERSERKER("광전사"),
    TANK("탱커"),
    HITMAN("히트맨"),
    SNIPER("스나이퍼"),
    ELEMENTIST("원소술사")
}
